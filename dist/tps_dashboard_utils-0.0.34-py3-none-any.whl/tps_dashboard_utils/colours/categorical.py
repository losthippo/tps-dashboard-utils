from tps_dashboard_utils.colours import colour_names as cn

pastel = ['#86E3CE', '#D0E6A5', '#FFDD94', '#FA897B', '#CCABDB']
rag = ['#FF7588', '#FFA87D', '#16D39A']
flat = [cn.mint, cn.aqua, cn.lavender, cn.bluejeans, cn.pink_rose, cn.grapefruit, cn.bittersweet, cn.sunflower,
        cn.grass, cn.light_grey, cn.mid_grey, cn.dark_grey]